umount ~/Library/Application\ Support/bedrock_world_editor/mounted_volumes/iPhone-Minecraft
umount ~/Library/Application\ Support/bedrock_world_editor/mounted_volumes/iPhone-MinecraftPreview