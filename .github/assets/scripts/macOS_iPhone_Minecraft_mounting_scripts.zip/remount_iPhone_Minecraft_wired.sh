umount ~/Library/Application\ Support/bedrock_world_editor/mounted_volumes/iPhone-Minecraft
umount ~/Library/Application\ Support/bedrock_world_editor/mounted_volumes/iPhone-MinecraftPreview
[ ! -d ~/Library/Application\ Support/bedrock_world_editor/mounted_volumes/iPhone-Minecraft ] && sudo install -d -o "$USER" -g staff ~/Library/Application\ Support/bedrock_world_editor/mounted_volumes/iPhone-Minecraft
[ ! -d ~/Library/Application\ Support/bedrock_world_editor/mounted_volumes/iPhone-MinecraftPreview ] && sudo install -d -o "$USER" -g staff ~/Library/Application\ Support/bedrock_world_editor/mounted_volumes/iPhone-MinecraftPreview
ifuse --documents com.mojang.minecraftpe ~/Library/Application\ Support/bedrock_world_editor/mounted_volumes/iPhone-Minecraft
ifuse --documents com.mojang.minecraftpreview ~/Library/Application\ Support/bedrock_world_editor/mounted_volumes/iPhone-MinecraftPreview